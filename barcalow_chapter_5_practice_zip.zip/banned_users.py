# They're all band users, right?
banned_users = ["genesis", "phoenix", "pilot"]

user = "phil_collins"

# Technically, phil_collins is not in that list...
if user not in banned_users:
    print(f"Welcome to the music posting site, {user.title()}!")
else:
    print("You have been banned from the music site.")