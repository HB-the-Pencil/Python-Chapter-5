# They just have a bland version of this program that doesn't do anything...
# Let's turn their variable check into a game!

# This took me way too long lol

answer = 42  # The answer to life, the universe, and everything.
validGuess = False
print("Guess a number between 1 and 100! Your guess: ",end="")
guess = input()

# Wish I could wrap this in a function.
while not validGuess:
    # Make sure it's not text.
    if guess.isalpha():
        guess = input("Type a number, not a letter! ")
    # Make sure it's a whole number. I'm proud of this method!
    elif float(guess) - round(float(guess)) != 0:
        guess = input("Type a whole number! ")
    # Make sure it's in range.
    elif int(guess) < 1 or int(guess) > 100:
        guess = input("Type a number between 1 and 100, silly. ")
    else:
        validGuess = True

# While the guess is incorrect, prompt for another guess.
while int(guess) != answer:
    guess = input("Nope! Guess again: ")

    # error-proofing it
    while not validGuess:
        # Make sure it's not text.
        if guess.isalpha():
            guess = input("Type a number, not a letter! ")
        # Make sure it's a whole number. I'm proud of this method!
        elif float(guess) - round(float(guess)) != 0:
            guess = input("Type a whole number! ")
        # Make sure it's in range.
        elif int(guess) < 1 or int(guess) > 100:
            guess = input("Type a number between 1 and 100, silly. ")
        else:
            validGuess = True

# After the user guesses the answer, tell them they were correct.
print("You guessed it!")