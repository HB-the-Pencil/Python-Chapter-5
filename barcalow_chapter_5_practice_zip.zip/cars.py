# If we would just make lists with capital letters already, we wouldn't have
# this problem...
cars = ["mini", "bmw", "honda", "acura", "toyota"]

for car in cars:
    if car == "bmw" or car == "mini":
        print(car.upper())
    else:
        print(car.title())

# Shh... don't tell them I'm using or statements already.

# Let's see if I can figure out the list comprehension version:
[print(car.upper() if car == "bmw" or car == "mini"
       else car.title()) for car in cars]

# It works, but it's pretty long and I can't figure out how to wrap it to keep
# with PEP 8 style.