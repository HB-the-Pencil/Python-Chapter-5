# Get the user's age. (I should teach myself try-accept statements early.)
age = int(input("How old are you? "))

# Tickets are free for people under 4 years old. It's $25 for kids (age 4-18)
# and $40 for adults (age 18+).
if age < 4:
    price = 0
elif age < 18:
    price = 25
elif age < 65:
    price = 40
else:
    price = 20

# As the book says, using elif age >= 65 at the end instead of else would
# catch all possible answers, but as PyCharm says, there is still a chance
# that price will be undefined. Thus, I left it as else.

# Look! I put list comprehension in an f-string!
print(f"Your ticket will be {"$"+str(price) if price > 0 else "free"}.")

# I have a bad habit of restating previous conditions in elif statements (for
# example, "elif age >= 4 and age < 18"). PyCharm is teaching me to break the
# habit. Their debugger is great!