# Get the user's age. They just have a variable, but I used an input so it's
# easier to test.
age = int(input("How old are you? "))

# If they're 18, they can vote!
if age >= 18:
    print("You can vote this year!")
    print("Make sure you register by November.")
else:
    print("You're too young to vote.")
    print(f"Only {18-age} years until you can vote!")