# Pizza time!
requested_toppings = ["mushrooms", "pepperoni", "pineapple", "ham"]
available_toppings = ["mushrooms", "pepperoni", "extra cheese",
                      "olives", "green peppers", "sausage"]

# Is there a list?
if requested_toppings:
    # Check the toppings and tell the user we're adding them.
    for topping in requested_toppings:
        if topping == "pineapple":
            print("Pineapple is a disgrace to pizza. I'm not adding that.")
        elif topping in available_toppings:
            print(f"Adding {topping}...")
        else:
            print(f"Sorry, we're out of {topping}.")
    print("\nPizza's ready!")
else:
    print("You really want a blank pizza?")